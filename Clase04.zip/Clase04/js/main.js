// linea de comentarios
/* bloque de comentarios */

// Javascript EMACS6

console.log("Hola Mundo!")
//alert("Hola Mundo JS")

function sumar(){
    nro1=parseFloat(document.getElementById("numero1").value)
    nro2=parseFloat(document.getElementById("numero2").value)
    resulado=nro1+nro2
    document.getElementById("resultado").value=resulado
}